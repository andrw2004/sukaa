<!DOCTYPE html>
<html lang="ru"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>404 Ошибка</title>
<link rel="stylesheet" type="text/css" href="/files/bootstrap.min.css">
</head>
<body class="" style="height:0%">
<div class="app-content container text-xs-center" style="padding-right:0px!important;">
<div class="content-wrapper">
<div class="content-body">
<section id="description-list-alignment" style="margin-top:15%">
<div class="row">
<h1 class="display-4 blue-grey darken-3">Страница не найдена</h1>
<div class="col-lg-2 offset-lg-5">
<button onclick="location.href='/'" style="margin-top:25px;color:#fff;background: #6c7a89!important; border: 0px solid; " type="button" class="bg-blue-grey bg-lighten-2  btn  btn-block mr-1 mb-1"> Hа главную</button>
</div>
</div>
</section>
</div>
</div>
</div>
</body></html>